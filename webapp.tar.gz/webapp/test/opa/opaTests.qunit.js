sap.ui.define([
	"sap/ui/test/Opa5",
	"com/globalretail/solutions/demokit/test/opa/arrangements/Startup",
	"com/globalretail/solutions/demokit/test/opa/StartpageJourney",
	"com/globalretail/solutions/demokit/test/opa/ReviewsJourney",
	"com/globalretail/solutions/demokit/test/opa/BackNavigationJourney"
], function (Opa5, Startup) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "com.globalretail.solutions.view.",
		autoWait: true
	});
});
