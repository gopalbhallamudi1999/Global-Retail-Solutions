sap.ui.define(function() {
	"use strict";

	return {
		name: "QUnit test suite for Global Retail Solutions",
		defaults: {
			page: "ui5://test-resources/com/globalretail/solutions/demokit/Test.qunit.html?testsuite={suite}&test={name}",
			qunit: {
				version: 2
			},
			sinon: {
				version: 1
			},
			ui5: {
				language: "EN",
				theme: "sap_horizon"
			},
			coverage: {
				only: "com/globalretail/solutions/demokit/",
				never: [
					"com/globalretail/solutions/demokit/test/"
				]
			},
			loader: {
				paths: {
					"com/globalretail/solutions/demokit": "../",
                    "com/globalretail/solutions": "../"
				}
			}
		},
		tests: {
			"unit/unitTests": {
				title: "Unit tests for Global Retail Solutions"
			},
			"opa/opaTests": {
				title: "Integration tests for Global Retail Solutions"
			}
		}
	};
});